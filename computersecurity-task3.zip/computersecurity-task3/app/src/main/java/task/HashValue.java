package task;

import com.google.common.base.Charsets;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
// import java.lang.Math;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
// MAP STATISTICALLY RELATED IMPORT
import java.util.Map;
import java.util.Scanner;
// TREEMAP STATISTICALLY RELATED IMPORT
import java.util.TreeMap;
// STATISTICALLY RELATED IMPORTS
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.SwingWrapper;


/**
 * CLASS FOR TASK 6A.
 */
public class HashValue {
  /**
   * CONVERTS A LINE OF A TEXT FILE INTO A FIXED SIZE HASH VALUE.
   * THE RETURNED HASH VALUE HAS A SIZE OF 8-BITS, SO A HASH TABLE
   * WITH 256 BUCKETS (ASCII VALUE).
   * THE FUNCTION SHOULD BE USED IN A FOR LOOP.
   *
   * @param line LINE OF TEXT FILE; ANY SIZE
   * @return integer hashValue OF SIZE 8-BITS
   */
  public int getValue(String line) {
    // GET RANDOM VALUE BUT NOT RANDOMIZED!!
    // IF RANDOMIZED, SAME INPUT COULD LEAD TO DIFFERENT OUTPUT EACH TIME
    int hashValue = 0;

    // REMOVING LEADING AND TRAILING WHITESPACE TO CLEAN THE LINE
    line = line.trim();

    int length = line.length();
    // GETTING ALL CHARACTERS IN THE LINE
    char[] characters = line.toCharArray();
    
    // GETTING COMPLETE HASH VALUE OF LINE
    for (char character : characters) {
      // METHOD FOR STRINGS .hashCode() ALSO USES *31
      // 31 ALSO SPREADS VALUES BETTER (THAN 32) IN TABLE SINCE 31 IS A PRIME
      // ADDING VALUE OF CHARACTER ASWELL AND
      // MODULO 256 BECAUSE OF THE 256 BUCKET REQUIREMENT (ASCII TABLE)
      // ADDING IT ALL TO THE CURRENT HASH VALUE
      // hashValue = (hashValue + (int) (Math.pow((character * 31), (length - 1)))) % 256;

      // THIS IS BETTER EVEN IF IT WAS A MISTAKE
      hashValue = (hashValue + character * 31 ^ (length - 1)) % 256;
      length--;
    }

    return hashValue;
  }
  
  /**
   * METHOD TO VALIDATE THE INPUT FILE.
   *
   * @param filename STRING; NAME OF FILE
   * @return CORRECTED AND/OR VERIFIED FILE NAME STRING
   */
  private String validateFilename(String filename) {
    // REMOVE WHITESPACE
    if (filename != null && !filename.isEmpty()) {
      filename = filename.trim();
    } else {
      // EMPTY FILENAME INPUT
      return filename = "Filename Empty!";
    }
    // INCORRECT FORMAT OF FILE
    if (!filename.endsWith(".txt")) {
      filename = filename + ".txt";
    }
    return filename;
  }

  /**
   * TURNS EACH LINE IN A FILE OF ANY SIZE INTO A HASH VALUE.
   *
   * @param filename STRING NAME OF THE FILE THAT SHOULD BE CONVERTED
   * @return ARRAY CONTAINING ALL HASH VALUES
   * @throws IOException ERRORANDLING FOR I/O
   */
  public int[] hashFile(String filename) throws IOException {

    // COMPLETING FILENAME (OR NOT)
    filename = validateFilename(filename);

    // PATH INSTANCES
    String a = "app";
    String b = "src";
    String c = "main";
    String d = "resources";
    
    // GET FILE PATH STRING
    String filepath = Paths.get(a, b, c, d, filename).toAbsolutePath().toString();
    
    // APPEARANTLY THIS IS THE EQUIVALENT TO .APPEND
    // WITH DYNAMIC LISTS IN PYTHON
    // ITS HARD TO UNDERSTAND BUT BEAR WITH ME
    ArrayList<Integer> allHashValues = new ArrayList<>();

    // TRYING TO READ FILE
    try (Scanner scanner = new Scanner(new File(filepath), Charsets.UTF_8)) {

      // FILE TO STORE HASH TABLE IN
      String outputName = filename.split("\\.")[0] + "_HashTable.txt";

      // PATH TO STORE NEW FILE IN
      Path outputPath = Paths.get(a, b, c, d, outputName);

      // CREATING FILE IN DESIRED PATH
      File hashTableFile = outputPath.toFile();
      hashTableFile.createNewFile();

      // OPENING WRITING MODE TO WRITE IN NEWLY CREATED FILE
      FileWriter hashValues = new FileWriter(hashTableFile);
      
      // DECLARING LINECOUNTER TO PRINT IN HASH TABLE RESULT LATER ON
      // INSTEAD OF LINES OF TEXT
      // MOSTLY TO SAVE SPACE BUT STILL NOT LOOSING TRACK OF
      // WHICH LINE IS MEANT
      int linecount = 0;

      // TACKLING ALL LINES ONE BY ONE
      while (scanner.hasNextLine()) {

        // COUNTING LINES
        linecount++;

        // RETRIEVING EACH LINE
        String line = scanner.nextLine();

        
        // SKIP EMPTY LINES
        // EMPTY LINES MAKE HASH TABLE TOO UNBALANCED!
        if (line.isEmpty()) {
          continue;

        // WORK ONLY WITH NON-EMPTY LINES
        } else {
          // GET THE HASH VALUE OF 
          int hashValue;
          hashValue = getValue(line);
          // ADDING EACH HASH VALUE TO THE ARRAY
          allHashValues.add(hashValue);
  
          // BUILD A STRING TO STORE ENCRYPTED LINE IN
          // STRINGBUILDER GETS RESET EACH ROW
          StringBuilder table = new StringBuilder();
  
          table.append("LINE: " + linecount + "-> Hash Value: ");
          table.append(Integer.toString(hashValue));
  
          // APPEND FINISHED ENCRYPTED LINE TO FINAL RESULT TEXT
          hashValues.write(table.toString());
          hashValues.write(System.lineSeparator());
        }
      }

      // CLOSING ALL ACTIVE CLASSES
      hashValues.close();
      scanner.close();

      // CONFIRMATION STATEMENT FOR COMPLETED ENCRYPTION
      System.out.println(
          "The file has been hashed and the " 
          + "results have been saved in the file " + outputName
      );

    } catch (IOException errormessage) {
      // ERROR HANDLIG WITH PRINTOUT FOR BETTER PROBLEM-SOLVING
      System.out.println("Some error has occured!");
      System.out.println(errormessage);
    }

    // GETTING SIZE OF LIST TO MAKE AN ARRAY
    int size = allHashValues.size();
    // MAKING FINAL ARRAY TO GET RETURNED
    int[] hashValuesList = new int[size];

    // ITERATING THROUGH EACH INDEX
    for (int index = 0; index < size; index++) {
      // PUSHING EACH VALUE AT EACH INDEX OF LIST INTO ARRAY AT SAME INDEX
      hashValuesList[index] = allHashValues.get(index);
    }

    return hashValuesList;
  }

  /**
   * METHOD TO GET THE AMOUNT OF APPEARANCES (FREQUENCIES) OF EACH HASH VALUE
   * IN A TEXT FILE.
   *
   * @param hashValuesList LIST CONTAINING ALL HASH VALUES OF EACH LINE IN ORDER
   * @return 2D ARRAY CONTAINING ALL FREQUENCIES OF EACH HASH VALUE
   */
  private int[] getFrequencies(int[] hashValuesList) {
    // CREATE ARRAY TO STORE FREQUENCIES OF EACH HASH VALUE
    // LENGTH = COUNTING 0 TO 255 HASH VALUES= 256
    int[] frequencyList = new int[256];

    // COUNTING FREQUENCIES BY INCREMENTING VALUE AT CORRESPONDING INDEX (HASH VALUE - 1)
    for (int currentHashValue : hashValuesList) {

      // INCREMENT VALUE AT THIS INDEX (HASH VALUE - 1)
      frequencyList[currentHashValue]++;
    }

    return frequencyList;
  }

  /**
   * MAKES A STATISTIC OUT OF THE FREQUENCIES OF HASH VALUES IN A TEXT FILE
   * AND THE HASH VALUES.
   * THE STATISTICAL NUMBERS SHOULD BE CLOSE TO EQUAL TO EACH OTHER,
   * OTHERWISE THE USED HASH FUNCTION SUCKS.
   *
   * @param filename NAME OF THE FILE THAT WAS USED TO CREATE THE HASH VALUES LIST
   * @param hashValuesList LIST CONTAINING ALL HASH VALUES OF EACH LINE IN ORDER
   */
  public void makeXchart(String filename, int[] hashValuesList) {
    // GET FREQUENCIES OF EACH HASH VALUE IN HASH VALUES LIST
    HashValue makeFrequencyList = new HashValue();
    int[] frequencyList = makeFrequencyList.getFrequencies(hashValuesList);

    // MAKE NEW INSTANCE OF TREE MAP (FOR STATISTICS)
    Map<Integer, Integer> statisticsMap = new TreeMap<>();

    int index = 0;

    // PUTTING ALL DATA INTO THE STATISTIC
    for (int frequency : frequencyList) {
      // PUTTING KEY(HASH VALUE) AND CORRESPONDING VALUE(FREQUENCY) IN STATISTIC
      // KEY = X-AXIS; VALUE = Y-AXIS
      int hashValue = index;

      statisticsMap.put(hashValue, frequency);

      index++;
    }

    // CONVERTING ALL KEYS AND VALUES INTO ARRAYS
    // FOR PROPER DISPLAYING OF DATA IN STATISTIC (X-AND Y-AXIS)
    Integer[] xaxisInt = statisticsMap.keySet().toArray(new Integer[0]);
    Integer[] yaxisInt = statisticsMap.values().toArray(new Integer[0]);

    // QUICK FIX!
    // CONVERTING INTERGER ARRAYS TO DOUBLE ARRAYS BECAUSE .addSeries
    // METHOD IS CRYING THAT IT DOESNT LIKE INTEGER ARRAYS...
    double[] xaxis = new double[xaxisInt.length];
    double[] yaxis = new double[yaxisInt.length];
    // I HATE USING i.. PLEASE FORGIVE ME
    for (int i = 0; i < xaxisInt.length; i++) {
      xaxis[i] = xaxisInt[i];
      yaxis[i] = yaxisInt[i];
    }

    // CREATE STATISTIC
    // TITLE IS HARDCODED AND IS JUST CHANGED WHEN NEEDED
    CategoryChart finalStatistic = new CategoryChartBuilder().width(1200)
        .height(400).title("Avalanche Test Results")
        .xAxisTitle("Hash Values").yAxisTitle("Amount Of Appearances")
        .build();

    // SOME COSMETIC STUFF
    finalStatistic.getStyler().setPlotMargin(0);
    finalStatistic.getStyler().setXAxisLabelRotation(270);
    finalStatistic.getStyler().setAvailableSpaceFill(1.0);
    // I WASNT ABLE TO FIND A METHOD THAT MAKES IT SO LESS X VALUES WOULD SHOW,
    // SO I REMOVED THEM IN THE PICTURE IN THE REPORT

    // MAKE LEGEND (PROBABLY UNECCESARY WITH ONE DATA DISPLAY)
    finalStatistic.addSeries("Appearances", xaxis, yaxis);

    // MAKING THE CHART VISIBLE BY DISPLAYING IT AFTER PLOTTING
    new SwingWrapper<>(finalStatistic).displayChart();
  }
}