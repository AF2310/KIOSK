package task;

import com.google.common.base.Charsets;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * RAIL FENCE CYPHER ARRANGES PLAINTEXT OR CYPHERTEXT IN A ZIG-ZAG WAY OVER
 * A CERTAIN AMOUNT OF RAILS AND THEN READS IT ROW BY ROW TO DE-OR ENCRYPT.
 */
public class RailFenceCypher {
  /**
   * METHOD TO VALIDATE THE INPUT FILE.
   *
   * @param filename STRING; NAME OF FILE
   * @return CORRECTED AND/OR VERIFIED FILE NAME STRING
   */
  public String validateFilename(String filename) {

    // REMOVE WHITESPACE
    if (filename != null && !filename.isEmpty()) {
      filename = filename.trim();

    } else {
      // EMPTY FILENAME INPUT
      return filename = "FALSE";
    }

    // INCORRECT FORMAT OF FILE
    if (!filename.endsWith(".txt")) {
      filename = filename + ".txt";
    }

    // FILENAME HAS BEEN CORRECTED (COMPLETED)
    return filename;
  }

  /**
   * ENCRYPTS THE FILE USING RAIL FENCE CYPHER.
   *
   * @param key INTEGER THAT DECIDES THE NUMBER OF RAILS
   * @param filename STRING NAME OF THE FILE TO BE ENCRYPTED
   * @throws IOException ERRORS WHEN SEARCHING FOR FILE OR OTHER I/O RELATED ERRORS
   */
  public void encrypt(int key, String filename) throws IOException {

    // SECTIONS OF FILE PATH
    String a = "app";
    String b = "src";
    String c = "main";
    String d = "resources";

    // GET FILE PATH STRING
    String filepath = Paths.get(a, b, c, d, filename).toAbsolutePath().toString();
    
    // TRYING TO READ FILE IN FILEPATH
    try (Scanner scanner = new Scanner(new File(filepath), Charsets.UTF_8)) {

      // FILENAME TO STORE ENCRYPTED RESULT IN
      // FILENAME CONTAINS LETTER OF CYPHER METHOD (R=RAIL FENCE CYPHER) + ENC (ENCRYPTED)
      String outputName = filename.split("\\.")[0] + "_Renc.txt";

      // PATH TO STORE NEW FILE IN
      Path outputPath = Paths.get(a, b, c, d, outputName);

      // CREATING FILE IN DESIRED PATH
      File encryptedFile = outputPath.toFile();
      encryptedFile.createNewFile();

      // OPENING WRITING MODE TO WRITE IN NEWLY CREATED FILE
      FileWriter cyphertext = new FileWriter(encryptedFile);

      // TACKLING ALL LINES ONE BY ONE
      while (scanner.hasNextLine()) {
        // RETRIEVING EACH LINE
        String line = scanner.nextLine();
        // CONVERTING LINE TO ARRAY OF SINGLE CHARACTERS
        char[] characters = line.toCharArray();
        // BUILD A STRING TO STORE ENCRYPTED LINE IN
        // STRINGBUILDER GETS RESET EACH ROW
        StringBuilder cypherline = new StringBuilder();

        // DECLARE ALL RAILS; AMOUNT DEPENDENT ON INPUT VARIABLE KEY
        StringBuilder[] rails = new StringBuilder[key];
        // CREATE EACH RAIL INDIVIDUALLY
        // THIS FOR LOOP IS LIKE 'FOR X IN RANGE...' IN PYTHON
        for (int railNumber = 0; railNumber < key; railNumber++) {
          // EACH RAIL WILL BE A STRING TO STORE THE CHARACTERS IN
          rails[railNumber] = new StringBuilder();
        }

        // WE START AT RAIL 0
        int currentRail = 0;
        // USING A BOOLEAN TO DECIDE WHETER TO GO UP OR DOWN
        // TURNS TRUE WHEN WE MEET RAIL 0 AND TURNS FALSE WHEN WE HIT BOTTOM RAIL
        // IS NOW FALSE BECAUSE IT WILL TURN TRUE LATER IN LOOP BECUASE CURRENT RAIL STARTS AT 0
        boolean movingDown = false;

        for (char character : characters) {
          // STORE CHARACTER IN THE CURRENT RAIL
          rails[currentRail].append(character);

          // IF WE REACH RAIL 0 OR BOTTOM RAIL, MOVINGDOWN BOOLEAN WILL BE REVERTED
          // TO EITHER FALSE OR TRUE AS EXPLAINED IN DECLARATION COMMENT
          // WE USE KEY-1 BECAUSE WE START AT RAIL 0 (KIND OF LIKE INDEXES IN A LIST)
          if (currentRail == 0 || currentRail == key - 1) {
            movingDown = !movingDown;
          }

          // MOVE TO NEXT RAIL -> DEPENDING ON BOOLEAN!!
          if (movingDown) {
            // MOVE MORE DOWN IF WE REACHED TOP RAIL/ DIDNT REACH BOTTOM RAIL YET
            currentRail++;
          } else {
            // MOVE MORE UP IF WE REACHED BOTTOM RAIL/ DIDNT REACH TOP RAIL (RAIL 0) YET
            currentRail--;
          }
        }

        // ADDING EACH RAIL ONE BY ONE TO CREATE COMPLETE CYPHERLINE
        for (StringBuilder rail : rails) {
          cypherline.append(rail);
        }

        // APPEND FINISHED ENCRYPTED LINE TO FINAL RESULT TEXT
        cyphertext.write(cypherline.toString());
        cyphertext.write(System.lineSeparator());
      }

      // CLOSING ALL ACTIVE CLASSES
      cyphertext.close();
      scanner.close();

      // CONFIRMATION STATEMENT FOR COMPLETED ENCRYPTION
      System.out.println(
          "The file has been encrypted and the " 
          + "results have been saved in the file " + outputName
      );
      
    } catch (IOException errormessage) {
      // ERROR HANDLIG WITH PRINTOUT FOR BETTER PROBLEM-SOLVING
      System.out.println("Some error has occured!");
      System.out.println(errormessage);
    }
  }

  /**
   * IT DECRYPTS THE CYPHERTEXT USING THE RAIL FENCE METHOD.
   * BY TAKING THE LENGTH OF A CYPHERTEXT, WE GET THE AMOUNT
   * OF COLUMNS IN THE MATRIX.
   * CALCULATING KEY*LENGTH OF CYPHERTEXT, WE GET THE COMPLETE
   * MAP OF THE MATRIX.
   *
   * @param key INTEGER THAT REPRESENTS THE AMOUNT OF RAILS
   * @param filename NAME OF THE FILE TO BE DECRYPTED
   * @throws IOException ERROR HANDLING OF NOT FOUND FILES AND OTHER I/O-RELATED ERRORS
   */
  public void decrypt(int key, String filename) throws IOException {

    // SECTIONS OF FILE PATH
    String a = "app";
    String b = "src";
    String c = "main";
    String d = "resources";

    // GET FILE PATH STRING
    String filepath = Paths.get(a, b, c, d, filename).toAbsolutePath().toString();
    
    // TRYING TO READ FILE IN FILEPATH
    try (Scanner scanner = new Scanner(new File(filepath), Charsets.UTF_8)) {

      // FILENAME TO STORE DECRYPTED RESULT IN
      // FILENAME CONTAINS LETTER OF CYPHER METHOD (R=RAIL FENCE CYPHER) + DEC (DECRYPTED)
      String outputName = filename.split("\\.")[0] + "_Rdec.txt";

      // PATH TO STORE NEW FILE IN
      Path outputPath = Paths.get(a, b, c, d, outputName);

      // CREATING FILE IN DESIRED PATH
      File decryptedFile = outputPath.toFile();
      decryptedFile.createNewFile();

      // OPENING WRITING MODE TO WRITE IN NEWLY CREATED FILE
      FileWriter plaintext = new FileWriter(decryptedFile);

      // TACKLING ALL LINES ONE BY ONE
      while (scanner.hasNextLine()) {
        // GETTING EACH LINE FROM THE CYPHERTEXT
        String line = scanner.nextLine();
        // GETTING LENGTH OF EACH LINE TO DETERMINE AMOUNT OF COLUMNS
        int lengthCypherline = line.length();

        // RECREATING RAIL PATTERN THAT EACH CHARACTER WAS STORED IN
        // IN THEIR ORIGINAL SLOT AND RAIL
        // (BASICALLY RECREATING THE ZIG-ZAG PATTERN)
        int[] originalRailSlots = new int[lengthCypherline];

        // STARTING POINT RAIL 0
        int currentRail = 0;

        // USING BOOLEAN TO DECIDE WHETER TO GO UP OR DOWN
        boolean movingDown = false;

        for (int origRailNumber = 0; origRailNumber < lengthCypherline; origRailNumber++) {
          // RECREATE RAILS
          originalRailSlots[origRailNumber] = currentRail;

          // IF WE REACH RAIL 0 OR LAST RAIL, MOVINGDOWN BOOLEAN WILL REVERT
          // TO EITHER FALSE OR TRUE; WE USE KEY-1 BECAUSE WE START AT RAIL 0
          if (currentRail == 0 || currentRail == key - 1) {
            movingDown = !movingDown;
          }
          // MOVE 1 RAIL LOWER IF BOTTOM RAIL NOT REACHED YET / TOP RAIL GOT REACHED
          if (movingDown) {
            currentRail++;
          // MOVE 1 RAIL UP IF RAIL 0 NOT REACHED YET / BOTTOM RAIL JUST GOT REACHED
          } else {
            currentRail--;
          }
        }

        // MAKING LIST OF INTEGERS TO COUNT CHARACTERS ON EACH RAIL
        int[] charactersOnEachRail = new int[key];

        // COUNT ORIGINAL AMOUNT OF CHARACTERS ON EACH RAIL / HOW MANY WOULD FIT ON EACH RAIL
        // COUNTING FROM RAIL 0 TO KEY-1; LIKE INDEXES
        for (int rail : originalRailSlots) {
          charactersOnEachRail[rail]++;
        }

        // CREATE LIST THAT WILL STORE STARTING INDEXES OF EACH RAIL
        // SIZE DEPENDS ON KEY VALUE -> LIST IS AS BIG AS THE AMOUNT OF RAILS THAT EXIST
        int[] railStartIndexes = new int[key];

        // STARTING INDEX ON RAIL 0 IS 0 AND LAST ONE IS CHARACTER COUNT - 1
        // BECAUSE OF ZIG-ZAG FORMAT
        // STARTING POINT IS 0 BECAUSE WE START AT RAIL 0 AND INDEX 0
        railStartIndexes[0] = 0;
    
        // GET ORIGINAL STARTING INDEX OF EACH RAIL
        // LOOPING THROUGH EACH RAIL
        for (int currentRailNum = 1; currentRailNum < key; currentRailNum++) {
          // STARTING INDEX OF EACH RAIL GETS CALCULATED BY:
          // STARTING INDEX OF PREVIOUS RAIL (SO CURRENT RAIL NUMBER - 1)
          // PLUS NUMBER OF CHARACTERS THAT ARE IN PREVIOUS RAIL
          // EXAMPLE: RAIL 1 HAS 3 CHARACTERS; RAIL 0 HAS 4 CHARACTERS
          //          RAILSTARTINDEX[RAIL 0] = 0
          //          RAILSTARTINDEX[RAIL 1] = RAILSTARTINDEX[PREV RAIL-> 1-1 = 0]
          //                                   + CHARACTERSONEACHRAIL[PREV RAIL]
          //                                 = 0 + 4 = 4 -> STARTING INDEX FOR RAIL 1 IS 4 
          //          (INDEX STARTS AT 0 AND RAIL 0 OCCUPIES SLOT 0 TO 3(4-1))
          railStartIndexes[currentRailNum] = railStartIndexes[currentRailNum - 1] 
              + charactersOnEachRail[currentRailNum - 1];
        }

        // CONVERT CYPHERTEXT LINE TO CHARACTER LIST TO GET EACH CHARACTER INDIVIDUALLY
        char[] cyphertextCharacters = line.toCharArray();

        // MAKE CHARACER LIST TO STORE EACH PLAINTEXT CHARACTER INDIVIDUALLY TO
        // MAKE SURE TO STORE THEM IN CORRECT SLOT
        char[] plaintextCharacters = new char[lengthCypherline];

        // RECREATE PLAINTEXT
        // FOR EACH SLOT IN PLAINTEXT
        // -> MOVE CHARACTER FROM CYPHERPOSITION TO CORRECT PLAINTEXT SLOT
        // NEXT FREE SLOT IS DETERMINED BY RAILSTARTINDEXES[ORIGINALRAIL]
        for (int positionPlaintext = 0; positionPlaintext < lengthCypherline; positionPlaintext++) {

          // DECLARE INTEGER THAT STORES NUMBER OF ORIGINAL RAIL A CHARACER WAS IN
          int originalRail = originalRailSlots[positionPlaintext];
          // DECLARE INTEGER INDEX THAT STORES NUMBER FOR NEXT CHARACTER SLOT OF CURRENT RAIL
          int indexNextCharacter = railStartIndexes[originalRail];

          // STORE CHARACTER FROM CYPHERTEXT IN CORRECT PLAINTEXT POSITION
          plaintextCharacters[positionPlaintext] = cyphertextCharacters[indexNextCharacter];
          // GO TO NEXT CARACTER OF CURRENT RAIL
          railStartIndexes[originalRail]++;
        }

        // Convert the character array back into a string.
        String plaintextline = new String(plaintextCharacters);

        // APPEND FINISHED DECRYPTED LINE TO FINAL RESULT TEXT
        plaintext.write(plaintextline.toString());
        plaintext.write(System.lineSeparator());
      }

      // CLOSING ALL ACTIVE CLASSES
      plaintext.close();
      scanner.close();

      // CONFIRMATION STATEMENT FOR COMPLETED DECRYPTION
      System.out.println(
          "The file has been decrypted and the " 
          + "results have been saved in the file " + outputName
      );
      
    } catch (IOException errormessage) {
      // ERROR HANDLIG WITH PRINTOUT FOR BETTER PROBLEM-SOLVING
      System.out.println("Some error has occured!");
      System.out.println(errormessage);
    }
  }
}
