package task;

import com.google.common.base.Charsets;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * CAESAR CYPHER ENCRYPTS FILES USING KEY AND SIMPLE MATH.
 * IT SHIFTS ALL CHARACTERS TO THE RIGHT DEPENDING ON THE KEY VALUE
 * (OR LOOPS TO THE START AGAIN IF CHARACTER INDEX DURING SHIFT OVER
 * MAX POSSIBLE CHARACTER IN TABLE)
 * WE USE ASCII CODE FOR EN- AND DECRYPTION -> 256 POSSIBLE CHARACTERS
 */
public class CaesarCypher {
  /**
   * METHOD TO VALIDATE THE INPUT FILE.
   *
   * @param filename STRING; NAME OF FILE
   * @return CORRECTED AND/OR VERIFIED FILE NAME STRING
   */
  public String validateFilename(String filename) {
    // REMOVE WHITESPACE
    if (filename != null && !filename.isEmpty()) {
      filename = filename.trim();
    } else {
      // EMPTY FILENAME INPUT
      // IF FILENAME.ISEMPTY()
      // throw new IllegalArgumentException("Filename can't be empty!");
      return filename = "FALSE";
    }
    // INCORRECT FORMAT OF FILE
    if (!filename.endsWith(".txt")) {
      filename = filename + ".txt";
    }
    return filename;
  }

  /**
   * ENCRYPTS THE FILE USING CAESAR CYPHER.
   *
   * @param key INTEGER REPRESENTING THE AMOUNT EACH CHARACTER GETS SHIFTED
   * @param filename STRING NAME FOR FILE THAT NEEDS ENCRYPTION
   * @throws IOException ERRORHANDLING
  */
  public void encrypt(int key, String filename) throws IOException {

    // JUST TO SHORTEN SOME LINES
    String a = "app";
    String b = "src";
    String c = "main";
    String d = "resources";

    // GET FILE PATH STRING
    String filepath = Paths.get(a, b, c, d, filename).toAbsolutePath().toString();
    
    // TRYING TO READ FILE
    try (Scanner scanner = new Scanner(new File(filepath), Charsets.UTF_8)) {

      // FILE TO STORE ENCRYPTED RESULT IN
      // FILENAME CONTAINS LETTER OF CYPHER METHOD (R=CAESAR CYPHER) + ENC (ENCRYPTED)
      String outputName = filename.split("\\.")[0] + "_Cenc.txt";

      // PATH TO STORE NEW FILE IN
      Path outputPath = Paths.get(a, b, c, d, outputName);

      // CREATING FILE IN DESIRED PATH
      File encryptedFile = outputPath.toFile();
      encryptedFile.createNewFile();

      // OPENING WRITING MODE TO WRITE IN NEWLY CREATED FILE
      FileWriter cyphertext = new FileWriter(encryptedFile);

      // TACKLING ALL LINES ONE BY ONE
      while (scanner.hasNextLine()) {
        // RETRIEVING EACH LINE
        String line = scanner.nextLine();
        // CONVERTING LINE TO ARRAY OF SINGLE CHARACTERS
        char[] characters = line.toCharArray();
        // BUILD A STRING TO STORE ENCRYPTED LINE IN
        // STRINGBUILDER GETS RESET EACH ROW
        StringBuilder cypherline = new StringBuilder();

        for (char character : characters) {

          // THERE ARE 95 PRINTABLE SYMBOLS IN UTF-8
          // PRINTABLE CHARACTERS ARE BETWEEN 32 AND 126
          // -> ONLY THOSE WILL BE ENCRYPTED
          if (character >= 32 && character <= 126) {
            // MAPPING BETWEEN VALUE 0 AND 94 (-> -32)
            // GET INDEX OF CHARACTER IN ASCII TABLE
            int characterIndex = (int) character - 32;
            // GET SHIFTED POSTION OF ENCRYPTED CHARACTER
            // OR LOOPS OVER TABLE LIMITATIONS STARTING OVER IF VALUE IS OVER LIMIT
            int encryptedPosition = (characterIndex + key) % 95;
            // GETTING NORMAL VALUE BACK TO MAP VALUE PROPERLY IN ASCII TABLE (-> +32)
            // SHIFT TO NEW POSITION AND GET NEW ENCRYPTED CHARACTER
            char encryptedCharacter = (char) (encryptedPosition + 32);
            // ADD ENCRYPTED CHARACTER TO STRING
            cypherline.append(encryptedCharacter);

          } else {
            cypherline.append(character);
          }
        }
        // APPEND FINISHED ENCRYPTED LINE TO FINAL RESULT TEXT
        cyphertext.write(cypherline.toString());
        cyphertext.write(System.lineSeparator());
      }

      // CLOSING ALL ACTIVE CLASSES
      cyphertext.close();
      scanner.close();

      // CONFIRMATION STATEMENT FOR COMPLETED ENCRYPTION
      System.out.println(
          "The file has been encrypted and the " 
          + "results have been saved in the file " + outputName
      );
      
    } catch (IOException errormessage) {
      // ERROR HANDLIG WITH PRINTOUT FOR BETTER PROBLEM-SOLVING
      System.out.println("Some error has occured!");
      System.out.println(errormessage);
    }
  }

  /**
   * ENCRYPTS THE FILE USING CAESAR CYPHER.
   *
   * @param key INTEGER REPRESENTING THE AMOUNT EACH CHARACTER GOT SHIFTED DURING ENCRYPTION
   * @param filename NAME OF THE FILE THAT GETS DECTRYPTED
   * @throws IOException ERRORS WHEN SEARCHING FOR FILE OR ANYTHING ELSE INPUT/OUTPUT RELATED
   */
  public void decrypt(int key, String filename) throws IOException {
    
    // JUST TO SHORTEN SOME LINES
    String a = "app";
    String b = "src";
    String c = "main";
    String d = "resources";

    // GET FILE PATH STRING
    String filepath = Paths.get(a, b, c, d, filename).toAbsolutePath().toString();
    
    // TRYING TO READ FILE
    try (Scanner scanner = new Scanner(new File(filepath), Charsets.UTF_8)) {

      // FILE TO STORE DECRYPTED RESULT IN
      // FILENAME CONTAINS LETTER OF CYPHER METHOD (R=CAESAR CYPHER) + DEC (DECRYPTED)
      String outputName = filename.split("\\.")[0] + "_Cdec.txt";

      // PATH TO STORE NEW FILE IN
      Path outputPath = Paths.get(a, b, c, d, outputName);

      // CREATING FILE IN DESIRED PATH
      File decryptedFile = outputPath.toFile();
      decryptedFile.createNewFile();

      // OPENING WRITING MODE TO WRITE IN NEWLY CREATED FILE
      FileWriter plaintext = new FileWriter(decryptedFile);

      // TACKLING ALL LINES ONE BY ONE
      while (scanner.hasNextLine()) {
        // RETRIEVING EACH LINE
        String line = scanner.nextLine();
        // CONVERTING LINE TO ARRAY OF SINGLE CHARACTERS
        char[] characters = line.toCharArray();
        // BUILD A STRING TO STORE DECRYPTED LINE IN
        // STRINGBUILDER GETS RESET EACH ROW
        StringBuilder plaintextline = new StringBuilder();

        for (char character : characters) {

          // THERE ARE 95 PRINTABLE SYMBOLS IN UTF-8
          // PRINTABLE CHARACTERS ARE BETWEEN 32 AND 126
          // -> ONLY THOSE WILL BE ENCRYPTED
          if (character >= 32 && character <= 126) {
            // MAPPING BETWEEN VALUE 0 AND 94 (-> -32)
            // GET INDEX OF CHARACTER IN ASCII TABLE
            int characterIndex = (int) character - 32;
            
            // CALCULATE INNER SUBSTRACTION FIRST TO PREVENT NEGATIVE VALUE % 95
            int innerValue = (characterIndex - key);
            
            // GET ORIGINAL POSITION OF CYPHERTEXT
            int decryptedPosition;
            // WHEN DOING MOD, NEGATIVE VALUES NOT ALLOWED
            // IN ENCRYTION WHEN INDEX WAS OVER 95, YOU LOOP OVER TABLE STARTING AT 0 AGAIN
            // IN DECRYPTION WHEN INDEX IS NEGATIVE, YOU DO THE SAME ONLY BACKWARDS
            if (innerValue < 0) {
              decryptedPosition = (95 + innerValue) % 95;

            // INNER VALUE POSITIVE -> NO NEED TO LOOP OVER BACKWARDS
            } else {
              decryptedPosition = innerValue % 95;
            }

            // GETTING NORMAL VALUE BACK TO MAP VALUE PROPERLY IN ASCII TABLE (-> +32)
            // SHIFT TO NEW POSITION AND GET NEW ENCRYPTED CHARACTER
            char decryptedCharacter = (char) (decryptedPosition + 32);

            // ADD DECRYPTED CHARACTER TO STRING
            plaintextline.append(decryptedCharacter);

          } else {
            plaintextline.append(character);
          }
        }
        // APPEND FINISHED DECRYPTED LINE TO FINAL RESULT TEXT
        plaintext.write(plaintextline.toString());
        plaintext.write(System.lineSeparator());
      }

      // CLOSING ALL ACTIVE CLASSES
      plaintext.close();
      scanner.close();

      // CONFIRMATION STATEMENT FOR COMPLETED DECRYPTION
      System.out.println(
          "The file has been decrypted and the " 
          + "results have been saved in the file " + outputName
      );
      
    } catch (IOException errormessage) {
      // ERROR HANDLIG WITH PRINTOUT FOR BETTER PROBLEM-SOLVING
      System.out.println("Some error has occured!");
      System.out.println(errormessage);
    }
  }
}
